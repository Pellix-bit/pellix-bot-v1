
import { getAnimesFromJikan } from './modules/jikan.js'
import { getEpisodesFromGoyabu } from './modules/goyabu.js'
import { saveToSupabase } from './helpers/supabase.js'
import { saveToSheet } from './helpers/sheet.js'
import { config } from './config.js'

async function main() {
  const animes = await getAnimesFromJikan()
  const episodes = await getEpisodesFromGoyabu(animes)

  await saveToSupabase(animes, episodes)
  await saveToSheet(animes)

  console.log('✅ PellixBot atualizado com sucesso!')
}

main()
