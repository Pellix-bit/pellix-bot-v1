# PellixBot v1
Bot automático para atualizar animes e episódios